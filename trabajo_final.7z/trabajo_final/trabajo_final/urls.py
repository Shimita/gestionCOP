"""trabajo_final URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import login, logout

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('gestionCOP.urls')),
    path('index/', include('gestionCOP.urls')),
    path('ListarTurnos/', include('gestionCOP.urls')),
    path('formNuevoTurno/', include('gestionCOP.urls')),
    path('formNuevoTurno/<horaTurno>', include('gestionCOP.urls')),
    path('agregarTurnos/<horaTurno>', include('gestionCOP.urls')),
    path('modificarTurnos/', include('gestionCOP.urls')),
    path('modificarTurnos/<int:idTurno>', include('gestionCOP.urls')),
    
    path('modificarTurnos/<int:idTurno>/<int:pacienteId>/<int:year>/<int:month>/<int:day>/<hour>/', include('gestionCOP.urls')),
    #path('modificarFechaTurno/', include('gestionCOP.urls')),
    path('nuevoPaciente/', include('gestionCOP.urls')),
    path('buscarPaciente/', include('gestionCOP.urls')),
    path('modificarPaciente/', include('gestionCOP.urls')),    
    path('modificarPaciente/<int:dni>', include('gestionCOP.urls')),
    path('pacientes/', include('gestionCOP.urls')),
    path('pacientes-agregar/', include('gestionCOP.urls')),
    path('listarPacientes/', include('gestionCOP.urls')),
    
    path('consultasMedicas/', include('gestionCOP.urls')),
    path('consultasMedicas/<int:idTurno>', include('gestionCOP.urls')),
    path('pacienteSexoProfesion', include('gestionCOP.urls')),
    path('pacienteSexoProfesion/<int:dni>', include('gestionCOP.urls')),
    path('listarPacientesAtendidos', include('gestionCOP.urls')),
    path('historiaClinica/', include('gestionCOP.urls')),
    path('historiaClinica/<int:idTurno>', include('gestionCOP.urls')),
    path('nuevoPedido/', include('gestionCOP.urls')),
    path('listarPedidos/', include('gestionCOP.urls')),
    path('modificarPedido/', include('gestionCOP.urls')),
    path('modificarPedido/<int:idPedido>', include('gestionCOP.urls')),
    path('listarPedidosTaller/', include('gestionCOP.urls')),
    path('asistenciaDePacientes/', include('gestionCOP.urls')),
    path('inasistencias/', include('gestionCOP.urls')),
    path('pedidosDePacientes/', include('gestionCOP.urls')),
    path('topProductosVendidos/', include('gestionCOP.urls')),
    path('ventasPorVendedores/', include('gestionCOP.urls')),
]
