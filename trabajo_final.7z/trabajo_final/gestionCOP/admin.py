from django.contrib import admin
from gestionCOP.models import Pacientes, Turnos, Consultas, Pedidos

# Register your models here.

admin.site.register(Pacientes)
admin.site.register(Turnos)
admin.site.register(Consultas)
admin.site.register(Pedidos)

