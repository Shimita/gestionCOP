import datetime
from django import forms
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from gestionCOP.models import Pacientes, Turnos, Consultas, Pedidos
from gestionCOP.forms import *
from gestionCOP.misFunciones import *
from django.db.models import Q
from datetime import time, timedelta
import time


# Create your views here.

# ----------------------------------------------------------------
# Vistas para el LOGIN/LOGOUT-------------------------------------
# ----------------------------------------------------------------



def redirecciona(request):
    return HttpResponseRedirect(reverse('gestionCOP:index'))

    
    
def index(request):
    
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        contexto = {'fechaActual':o_FechaActual, 'rol':rol}
        return render(request, "gestionCOP/index.html", contexto)

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            o_FechaActual = objetoFechaHoy()
            rol = defineRol(request)
            contexto = {'fechaActual':o_FechaActual, 'rol':rol}
            return render(request, "gestionCOP/index.html", contexto)
        else:
            return render(request, "gestionCOP/login.html", {
                "mensaje":"Usuario o clave incorrectos"
            })
    return render(request, "gestionCOP/login.html")

def logout_view(request):
    logout(request)
    return render(request, "gestionCOP/login.html", {
        "mensaje": "Se ha desconectado exitosamente"
    })

# ----------------------------------------------------------------
# Vistas para los TURNOS------------------------------------------
# ----------------------------------------------------------------

def listarTurnos(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
        
            
            form = Calendario()
            if request.method == "POST":
                
                fecha = request.POST.get('date')
                fecha = datetime.datetime.strptime(fecha, '%d/%m/%Y')
                fecha = datetime.date(fecha.year, fecha.month, fecha.day)
                o_fechaBuscada = fecha
                
                o_todosLosTurnosOcupados = Turnos.objects.all().order_by('fechaTurno')
                o_TurnosOcupadosDelDiaBuscado = o_todosLosTurnosOcupados.filter(fechaTurno__date=o_fechaBuscada)
                o_TurnosOcupadosDelDiaBuscado = o_TurnosOcupadosDelDiaBuscado.filter(cancelado__exact=0)
                a_turnosOcupadosDelDiaBuscado = turnosOcupadosAArreglo(o_TurnosOcupadosDelDiaBuscado)
                a_datosDeTurnos = planillaDeTurnos(a_turnosOcupadosDelDiaBuscado, o_fechaBuscada)
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'form':form, 'fechaBuscada':o_fechaBuscada, 'turnos':a_datosDeTurnos}
                return render(request, "gestionCOP/listarTurnos.html", contexto)
            else:
                o_todosLosTurnosOcupados = Turnos.objects.all().order_by('fechaTurno')
                o_TurnosOcupadosDelDia = o_todosLosTurnosOcupados.filter(fechaTurno__date=o_FechaActual)
                o_TurnosOcupadosDelDia = o_TurnosOcupadosDelDia.filter(cancelado__exact=0)
                a_turnosOcupadosDelDia = turnosOcupadosAArreglo(o_TurnosOcupadosDelDia)
                a_datosDeTurnos = planillaDeTurnos(a_turnosOcupadosDelDia, o_FechaActual)
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'form':form, 'fechaBuscada':o_FechaActual, 'turnos':a_datosDeTurnos}
                return render(request, "gestionCOP/listarTurnos.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})

def formNuevoTurno(request, horaTurno):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            
            rol = defineRol(request)
            o_fechaDelTurno = fechaACadena(horaTurno)
            o_fechaDeCreacion = datetime.datetime.now()
            c_operador = request.user.username
            if request.method == "POST":
                datosDelFormulario = FormTurnoNuevo(request.POST)
                if datosDelFormulario.is_valid():
                    dni = datosDelFormulario.cleaned_data['dni']
                    nombre = datosDelFormulario.cleaned_data['nombre']
                    apellido = datosDelFormulario.cleaned_data['apellido']
                    if Pacientes.objects.filter(pk=dni):
                        paciente = Pacientes.objects.get(pk = dni)
                        paciente.nombre = nombre
                        paciente.apellido = apellido
                        paciente.save()
                        dni_fk = Pacientes.objects.get(pk = dni) # Obtengo el objeto de TipoCliente
                        turno = Turnos()
                        turno.dni_fk = dni_fk
                        turno.fechaTurno = o_fechaDelTurno
                        turno.fechasSolicitud = o_fechaDeCreacion
                        turno.operador = c_operador
                        turno.cancelado = False
                        turno.save()
                    else:
                        obj, created = Pacientes.objects.get_or_create(dni=dni, nombre=nombre , apellido= apellido,)
                        dni_fk = Pacientes.objects.get(pk = dni) # Obtengo el objeto de TipoCliente
                        turno = Turnos()
                        turno.dni_fk = dni_fk
                        turno.fechaTurno = o_fechaDelTurno
                        turno.fechasSolicitud = o_fechaDeCreacion
                        turno.operador = c_operador
                        turno.cancelado = False
                        turno.save()
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje':f'Se ha creado exitosamente el turno para {nombre} {apellido}: {o_fechaDelTurno}'}
                return render(request, "gestionCOP/nuevo-turno.html", contexto)
                #return HttpResponseRedirect(reverse('gestionCOP:listarTurnos'))            
            else:
                form = FormTurnoNuevo()
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'form': form, 'Hora': o_fechaDelTurno}
                return render(request, 'gestionCOP/nuevo-turno.html', contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})

def modificarTurnos(request, idTurno):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            
            rol = defineRol(request)
            medicos = recuperarMedicos()
            formulario = FormModificarTurno()
            form = Calendario2()
            if request.method == "POST":
                turno = Turnos.objects.get(pk=idTurno)
                paciente = turno.dni_fk
                pacienteId = paciente.dni
                fechaTurno = turno.fechaTurno
                fechaTurno = fechaTurno.strftime('%d/%m/%Y %H:%M')
                datosForm = FormModificarTurno(request.POST)
                if datosForm.is_valid():
                    cancelado = datosForm['cancelar']
                    if 'cancelar' in request.POST:
                        turno.cancelado = True
                        turno.save()
                        mensajeB = f"Ha cancelado el turno del  paciente {paciente} del {fechaTurno}."
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB}
                        return render (request, 'gestionCOP/modificarTurnos.html', contexto)                
                    else:
                        turno.cancelado = False
                        medico = datosForm.cleaned_data['medico']
                        nombreMedico = medico.first_name
                        apellidoMedico = medico.last_name
                        nomApellidoMedico = nombreMedico + ' ' + apellidoMedico
                        turno.medico = nomApellidoMedico
                        turno.save()
                    
                        fecha = request.POST.get('date')
                        if fecha:
                            fecha = datetime.datetime.strptime(fecha, '%d/%m/%Y')
                            fecha = datetime.date(fecha.year, fecha.month, fecha.day)
                        
                            fechaSeleccionada = fecha
                            o_todosLosTurnosOcupados = Turnos.objects.all().order_by('fechaTurno')
                            o_TurnosOcupadosDelDia = o_todosLosTurnosOcupados.filter(fechaTurno__date=fechaSeleccionada)
                            a_turnosOcupadosDelDia = turnosOcupadosAArreglo(o_TurnosOcupadosDelDia)
                            a_datosDeTurnos = planillaDeTurnos(a_turnosOcupadosDelDia, fechaSeleccionada)               
                        
                            mensajeB = f"Modificando el turno asignado a {paciente} del {fechaTurno} al {fecha}."
                        
                            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB, 'form':formulario, 'fecha':fecha, 'idTurno':idTurno, 'pacienteId':pacienteId, 'turnos':a_datosDeTurnos}                
                            return render (request, 'gestionCOP/modificarTurnos.html', contexto)

                        else:
                            mensajeB = f"El paciente {paciente} del turno {fechaTurno} a sido asignado a {nomApellidoMedico}"
                            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB, 'form':formulario}
                            return render (request, 'gestionCOP/modificarTurnos.html', contexto)
                else:
                    return render (request, 'gestionCOP/modificarTurnos.html', {'fechaActual':o_FechaActual, 'rol':rol,})
            else:
                formulario = FormModificarTurno()
                turno = Turnos.objects.get(pk=idTurno)
                paciente = turno.dni_fk
                fechaTurno = turno.fechaTurno
                fechaTurno = fechaTurno.strftime('%d/%m/%Y %H:%M')
                mensajeA = f"Modificando turno de {paciente} asignado al {fechaTurno}"        
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'formulario':formulario, 'medico':medicos, 'id':idTurno, 'mensajeA':mensajeA, 'form':form}
                return render (request, 'gestionCOP/modificarTurnos.html', contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})
        
def modificarTurnosAlDia(request, idTurno, pacienteId, year, month, day, hour ):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            
            rol = defineRol(request)
            fechaActual = datetime.datetime.now()
            usuario  = request.user.username
            
            #Modifico y cancelo el turno anterior
            turnoAnterior = Turnos.objects.get(pk=idTurno)
            turnoAnterior.fechaModificacion = fechaActual
            turnoAnterior.operadorMod = usuario
            turnoAnterior.cancelado = 1
            turnoAnterior.save()
            
            #Creo un turno en la nueva fecha
            horaTurno = hour[0:2]
            horaTurno = int(horaTurno)
            minutoTurno = hour[3:5]
            minutoTurno = int(minutoTurno)
            fechaTurno = datetime.datetime(year, month, day, horaTurno, minutoTurno)
            
            dni_fk = Pacientes.objects.get(pk = pacienteId) # Obtengo el objeto de TipoCliente
            turno = Turnos()
            turno.dni_fk = dni_fk
            turno.fechaTurno = fechaTurno
            turno.fechasSolicitud = fechaActual
            turno.operador = usuario
            turno.cancelado = False
            turno.save()
            
            nomApellidoPaciente = dni_fk.nombre + " " + dni_fk.apellido
            mensajeC = f"Se ha modificado exitosamente el turno de {nomApellidoPaciente} para el {fechaTurno}."
            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeC':mensajeC}

            return render(request, 'gestionCOP/modificarTurnos.html', contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})




# ----------------------------------------------------------------
# Vistas para los PACIENTES---------------------------------------
# ----------------------------------------------------------------

def nuevoPaciente(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            
            rol = defineRol(request)
            if request.method == 'POST':
                datosDelFormulario = FormTurnoNuevo(request.POST)
                if datosDelFormulario.is_valid():
                    nombre = datosDelFormulario.cleaned_data['nombre']
                    apellido = datosDelFormulario.cleaned_data['apellido']
                    dni = datosDelFormulario.cleaned_data['dni']
                    if Pacientes.objects.filter(pk=dni):
                        #Si existe solo actualizo los datos
                        paciente = Pacientes.objects.get(pk = dni)
                        paciente.nombre = nombre
                        paciente.apellido = apellido
                        paciente.obraSocial = request.POST.get('obraSocial')
                        paciente.telefono = request.POST.get('telefono')
                        paciente.email = request.POST.get('email')
                        fechaNac = request.POST.get('date')
                        fechaNac = datetime.datetime.strptime(fechaNac, '%d/%m/%Y')
                        fechaNac = datetime.date(fechaNac.year, fechaNac.month, fechaNac.day)                
                        paciente.fechaNacimiento = fechaNac
                        paciente.save()
                        mensajeB = f"El paciente {paciente} ya se encontraba registrado. Se actualizaron sus datos."
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB}
                    else:
                        paciente = Pacientes()
                        paciente.nombre = nombre
                        paciente.apellido = apellido
                        paciente.dni = dni
                        paciente.obraSocial = request.POST.get('obraSocial')
                        paciente.telefono = request.POST.get('telefono')
                        paciente.email = request.POST.get('email')
                        fechaNac = request.POST.get('date')
                        fechaNac = datetime.datetime.strptime(fechaNac, '%d/%m/%Y')
                        fechaNac = datetime.date(fechaNac.year, fechaNac.month, fechaNac.day)                
                        paciente.fechaNacimiento = fechaNac
                        paciente.save()                
                        mensajeA = f"Se ha registrado al paciente {paciente} correctamente."
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensajeA}
                    return render(request, "gestionCOP/nuevoPaciente.html", contexto)

            else:
                formNuevoPaciente = NuevoPaciente()
                fechaNacimiento = FechaNacimiento()
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'formulario':formNuevoPaciente, 'form':fechaNacimiento}
                return render(request, "gestionCOP/nuevoPaciente.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})
    
    
    
def buscarPaciente(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            rol = defineRol(request)
            if request.method == "POST":
                busqueda = request.POST.get('busqueda')
                if busqueda == 'dni':
                    formDNI = BuscarPorDNI(request.POST)
                    if formDNI.is_valid():
                        dniBuscado = formDNI.cleaned_data['dni']
                        paciente = Pacientes.objects.filter(dni__exact= dniBuscado)
                        if paciente.exists():
                            paciente = Pacientes.objects.get(pk=dniBuscado)
                            nombre = paciente.nombre + " " + paciente.apellido
                            mensaje = f"Editando información de {nombre}, DNI {paciente.dni}."
                            
                            dni = paciente.dni
                            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'dni':dni, 'paciente':paciente}
                            return render(request, 'gestionCOP/buscarPaciente.html', contexto)    
                        else:            
                            mensaje = f"No se han encontrado pacientes con el DNI {dniBuscado}."
                            formDNI = BuscarPorDNI()
                            formNombre = BuscarPorNombre()
                            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje,'formNombre':formNombre, 'formDNI':formDNI}
                            return render(request, 'gestionCOP/buscarPaciente.html', contexto)
                    mensaje = dniBuscado
                elif busqueda == 'nombre':
                    formNombre = BuscarPorNombre(request.POST)
                    if formNombre.is_valid():
                        nombreBuscado = formNombre.cleaned_data['nombre']
                        pacientes = Pacientes.objects.filter(Q(nombre__icontains=nombreBuscado) | Q(apellido__icontains=nombreBuscado))
                        if pacientes.exists():
                            cantidad = Pacientes.objects.filter(Q(nombre__icontains=nombreBuscado) | Q(apellido__icontains=nombreBuscado)).count()
                            mensaje = f"Se han encontrado {cantidad} pacientes."
                            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje':mensaje, 'pacientes':pacientes}
                            return render(request, 'gestionCOP/buscarPaciente.html', contexto)         

                        else:
                            mensaje = f"No se han encontrado pacientes con el nombre {nombreBuscado}."
                            formDNI = BuscarPorDNI()
                            formNombre = BuscarPorNombre()
                            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje,'formNombre':formNombre, 'formDNI':formDNI}
                        return render(request, 'gestionCOP/buscarPaciente.html', contexto)
            else:
                formDNI = BuscarPorDNI()
                formNombre = BuscarPorNombre()
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'formNombre':formNombre, 'formDNI':formDNI}
                return render(request, "gestionCOP/buscarPaciente.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})


'''def modificarPaciente(request, dni):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            o_FechaActual = objetoFechaHoy()
            rol = defineRol(request)
            if request.method == 'POST':
                datosDelFormulario = NuevoPaciente(request.POST)
                if datosDelFormulario.is_valid():
                    nombre = datosDelFormulario.cleaned_data['nombre']
                    apellido = datosDelFormulario.cleaned_data['apellido']
                    dni = datosDelFormulario.cleaned_data['dni']
                    if Pacientes.objects.filter(pk=dni):
                        #Si existe solo actualizo los datos
                        paciente = Pacientes.objects.get(pk = dni)
                        paciente.nombre = nombre
                        paciente.apellido = apellido
                        paciente.obraSocial = request.POST.get('obraSocial')
                        paciente.telefono = request.POST.get('telefono')
                        paciente.email = request.POST.get('email')
                        fechaNac = request.POST.get('date')
                        fechaNac = datetime.datetime.strptime(fechaNac, '%d/%m/%Y')
                        fechaNac = datetime.date(fechaNac.year, fechaNac.month, fechaNac.day)                
                        paciente.fechaNacimiento = fechaNac
                        paciente.save()
                        mensajeB = f"El paciente {paciente} ya se encontraba registrado. Se actualizaron sus datos."
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB}
                        return render(request, "gestionCOP/modificarPaciente.html", contexto)
            else:
                formNuevoPaciente = NuevoPaciente()
                fechaNacimiento = FechaNacimiento()
                
                mensaje = f"Modificando información del paciente"
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'formulario':formNuevoPaciente, 'form':fechaNacimiento, 'mensajeB':mensaje}
                return render(request, "gestionCOP/modificarPaciente.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})'''


def modificarPaciente(request, dni):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            o_FechaActual = objetoFechaHoy()
            rol = defineRol(request)
            if request.method == 'POST':
                datosDelFormulario = NuevoPaciente(request.POST)
                dni = request.POST.get('dni')
                if Pacientes.objects.filter(pk=dni):
                    paciente = Pacientes.objects.get(pk = dni)
                    paciente.nombre = request.POST.get('nombre')
                    paciente.apellido = request.POST.get('apellido')
                    paciente.dni = request.POST.get('dni')
                    paciente.obraSocial = request.POST.get('obraSocial')
                    paciente.telefono = request.POST.get('telefono')
                    paciente.email = request.POST.get('email')
                    fechaNac = request.POST.get('date')
                    fechaNac = datetime.datetime.strptime(fechaNac, '%d/%m/%Y')
                    fechaNac = datetime.date(fechaNac.year, fechaNac.month, fechaNac.day)                
                    paciente.fechaNacimiento = fechaNac
                    paciente.save()
                    mensajeB = f"El paciente {paciente} ya se encontraba registrado. Se actualizaron sus datos."
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB}
                    return render(request, "gestionCOP/modificarPaciente.html", contexto)
                
                '''if datosDelFormulario.is_valid():
                    nombre = datosDelFormulario.cleaned_data['nombre']
                    apellido = datosDelFormulario.cleaned_data['apellido']
                    dni = datosDelFormulario.cleaned_data['dni']
                    if Pacientes.objects.filter(pk=dni):
                        #Si existe solo actualizo los datos
                        paciente = Pacientes.objects.get(pk = dni)
                        paciente.nombre = nombre
                        paciente.apellido = apellido
                        paciente.obraSocial = request.POST.get('obraSocial')
                        paciente.telefono = request.POST.get('telefono')
                        paciente.email = request.POST.get('email')
                        fechaNac = request.POST.get('date')
                        fechaNac = datetime.datetime.strptime(fechaNac, '%d/%m/%Y')
                        fechaNac = datetime.date(fechaNac.year, fechaNac.month, fechaNac.day)                
                        paciente.fechaNacimiento = fechaNac
                        paciente.save()
                        mensajeB = f"El paciente {paciente} ya se encontraba registrado. Se actualizaron sus datos."
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB}
                        return render(request, "gestionCOP/modificarPaciente.html", contexto)
                return render(request, "gestionCOP/index.html")'''
            else:    
                formNuevoPaciente = NuevoPaciente()
                fechaNacimiento = FechaNacimiento()
                
                mensaje = f"Modificando información del paciente"
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'formulario':formNuevoPaciente, 'form':fechaNacimiento, 'mensajeB':mensaje}
                return render(request, "gestionCOP/modificarPaciente.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})

def listarPacientes(request):
    if not request.user.is_authenticated:
        contexto = {'fechaActual':o_FechaActual, 'rol':rol, "mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            
            rol = defineRol(request)
            pacientes = Pacientes.objects.all().order_by('apellido')
            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'pacientes':pacientes}
            return render(request, "gestionCOP/pacientes.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})

def pacientesAgregar(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        rol = defineRol(request)
        o_FechaActual = objetoFechaHoy()
        if (rol =='Secretaría') or (rol =='Gerencia'):
            
            rol = defineRol(request)
            if request.method == "POST":
                form = formNuevoPaciente(request.POST)
                if form.is_valid():
                    paciente = form.cleaned_data["paciente"]
                    pacientesC.append(paciente)
                    return HttpResponseRedirect(reverse("gestionCOP:pacientes"))
                else:
                    return render(request, "gestionCOP/pacientes-agregar.", {
                        'fechaActual':o_FechaActual, 'rol':rol,  "form" : form
                    })
            else:
                formDNI = BuscarPorDNI()
                formNombre = BuscarPorNombre()
                contexto = {'fechaActual':o_FechaActual, 'rol':rol,  'formNombre':formNombre, 'formDNI':formDNI}
                return render(request, "gestionCOP/pacientes-agregar.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})

def consultasMedicas(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Médico') or (rol =='Gerencia'):
            rol = defineRol(request)
            fechaActual = datetime.datetime.now()
            fechaActual = datetime.date(fechaActual.year, fechaActual.month, fechaActual.day)
            c_usuario = request.user.first_name + " " + request.user.last_name
            
            
            o_todosLosTurnosOcupados = Turnos.objects.all().order_by('fechaTurno')
            turnosAsignados = o_todosLosTurnosOcupados.filter(Q(fechaTurno__date=fechaActual) & Q(medico__iexact=c_usuario))
            mensajeA = f"Listando turnos asignados a {request.user.username}"
            contexto = {'fechaActual':o_FechaActual, 'rol':rol,  'fechaActual':fechaActual,'turnos':turnosAsignados, 'mensajeA':mensajeA}
            return render(request, "gestionCOP/consultasMedicas.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            

def nuevaConsultaMedica(request, idTurno):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Médico') or (rol =='Gerencia'):
            rol = defineRol(request)
            if request.method == "POST":
                datosForm = NuevaConsulta(request.POST)
                if datosForm.is_valid():
                    try:
                        consulta = Consultas.objects.get(turno_fk = idTurno)
                        consulta.motivo = datosForm.cleaned_data["motivo"]
                        consulta.diagnostico = datosForm.cleaned_data["diagnostico"]
                        idTurno = Turnos.objects.get(pk=idTurno)
                        consulta.turno_fk = idTurno
                        consulta.save()
                        mensaje = "Se ha modificado la información sobre la consulta médica del paciente de forma exitosa"
                        return render(request, "gestionCOP/consultasMedicas.html", {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensaje})                
                    except Consultas.DoesNotExist:
                        consulta = Consultas()
                        consulta.motivo = datosForm.cleaned_data["motivo"]
                        consulta.diagnostico = datosForm.cleaned_data["diagnostico"]
                        idTurno = Turnos.objects.get(pk=idTurno)
                        consulta.turno_fk = idTurno
                        consulta.save()
                        mensaje = "Se ha modificado la información de forma exitosa"
                        return render(request, "gestionCOP/consultasMedicas.html", {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensaje})
            else:
                form = NuevaConsulta()
                turno = Turnos.objects.get(id=idTurno)
                horaTurno = turno.fechaTurno
                paciente = turno.dni_fk
                nombrePaciente = paciente.nombre + " " + paciente.apellido
                mensaje = f"Consulta de {nombrePaciente} de  la fecha {horaTurno}"
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensaje, 'form':form, 'paciente':paciente}
                return render(request, "gestionCOP/consultasMedicas.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            

def pacienteSexoProfesion(request, dni):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Médico') or (rol =='Gerencia'):
            rol = defineRol(request)
            if request.method == "POST":
                datosForm = PacienteSexoProfesion(request.POST)
                if datosForm.is_valid():
                    sexo = datosForm.cleaned_data['sexo']
                    profesion = datosForm.cleaned_data['profesion']
                    app = datosForm.cleaned_data['app']
                    apf = datosForm.cleaned_data['apf']
                    paciente = Pacientes.objects.get(pk= dni)
                    paciente.sexo = sexo
                    paciente.profesion = profesion
                    paciente.antecedentesPaciente = app
                    paciente.antecedentesFamilia = apf
                    paciente.save()
                    mensaje = "Se edito la información medica de forma exitosa."
                    return render(request, "gestionCOP/pacienteSexoProfesion.html", {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensaje})
            else:
                paciente = Pacientes.objects.get(pk = dni)
                mensaje = f"Modificando datos de {paciente.nombre} {paciente.apellido}."
                form = PacienteSexoProfesion()
                contexto = {'fechaActual':o_FechaActual, 'rol':rol,  'form':form, 'mensajeA':mensaje}
                return render(request, "gestionCOP/pacienteSexoProfesion.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            
    
def listarPacientesAtendidos(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Médico') or (rol =='Gerencia'):
            if request.method == "POST":
                datosForm = PacientesPorFecha(request.POST)
                if datosForm.is_valid():
                    tipo = request.POST.get('tipo')
                    fecha = datosForm.cleaned_data['valor']
                    fecha = datetime.date(fecha.year, fecha.month, fecha.day)
                    c_usuario = request.user.first_name + " " + request.user.last_name

                    if tipo == 'Dia':
                        turnosDelDia = Turnos.objects.filter(fechaTurno__date=fecha)
                        mensajeA = f"Listando pacientes de la fecha {fecha}"       
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'fechaActual':o_FechaActual, 'mensajeA':mensajeA, 'turnos':turnosDelDia, 'medico':c_usuario}
                        
                    elif tipo == 'Mes':
                        turnosDelDia = Turnos.objects.filter(fechaTurno__month=fecha.month)
                        mensajeA = f"Listando pacientes del mes {fecha.month}"       
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'fechaActual':o_FechaActual, 'mensajeA':mensajeA, 'turnos':turnosDelDia, 'medico':c_usuario}                
                    elif tipo == 'Año':
                        turnosDelDia = Turnos.objects.filter(fechaTurno__year=fecha.year)
                        mensajeA = f"Listando pacientes del año {fecha.year}"       
                        contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'fechaActual':o_FechaActual, 'mensajeA':mensajeA, 'turnos':turnosDelDia, 'medico':c_usuario}                
                        
                        mensajeA = "Año"
                    else:
                        mensajeA = "Ingrese una fecha válida."
                    return render(request, 'gestionCOP/listarPacientesAtendidos.html', contexto)
                else:
                    mensajeA = "Ingrese una fecha válida."   
                    form = PacientesPorFecha({'tipo':'Dia'})
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA': mensajeA, 'form':form}
                    return render(request, 'gestionCOP/listarPacientesAtendidos.html', contexto)
                    
                    
                    
            else:
                form = PacientesPorFecha({'tipo':'Dia'})
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'form':form}
                return render(request, "gestionCOP/listarPacientesAtendidos.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            

def historiaClinica(request, idTurno):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Médico') or (rol =='Gerencia'):
            turno = Turnos.objects.get(id=idTurno)
            consultas = Consultas.objects.filter(turno_fk=turno.id)
            paciente = turno.dni_fk
            turnosDelPaciente = Turnos.objects.filter(dni_fk=paciente.dni)
            idTurnos = []
            for turno in turnosDelPaciente:
                idTurno = turno.id
                idTurnos.append(idTurno)
            datosDeTodasLasConsultas = []
            for idTurno in idTurnos:
                try:
                    consulta = Consultas.objects.get(turno_fk=idTurno)
                    datosDeConsulta = []
                    turno = Turnos.objects.get(pk=idTurno)
                    datosDeConsulta.append(turno.fechaTurno)
                    datosDeConsulta.append(consulta.motivo)
                    datosDeConsulta.append(consulta.diagnostico)
                    mensaje = datosDeConsulta
                    datosDeTodasLasConsultas.append(datosDeConsulta)
                except Consultas.DoesNotExist:
                    pass
            mensaje = "Información clínica del paciente"
            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensaje, 'paciente':paciente, 'consultas':datosDeTodasLasConsultas, 'idTurno':idTurno}
            return render(request, "gestionCOP/historiaClinica.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            


def nuevoPedido(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Ventas') or (rol =='Gerencia'):
            if request.method == 'POST':
                pedido = request.POST
                cantProductos = request.POST.get('oculto')
                
                lista_tipos_productos = []
                lista_detallada_productos = []
                for i in range(0, int(cantProductos)):
                    i = i + 1
                    claveProducto = 'select_tipo_prod' + str(i)
                    tipo_producto = request.POST.get(claveProducto)
                    if tipo_producto != None:
                        producto = []
                        
                        lista_tipos_productos.append(tipo_producto)
                        
                        if tipo_producto == 'lentes':
                            producto.append('Lente')
                            lateralidad = 'lateralidad_lente' + str(i)
                            lateralidad = request.POST.get(lateralidad)
                            producto.append(lateralidad)
                            material = 'material_lente' + str(i)
                            material = request.POST.get(material)
                            convergencia = 'convergencia_lente' + str(i)
                            convergencia = request.POST.get(convergencia)
                            producto.append(convergencia)
                            producto.append(material)
                            graduacionPrimera = 'graduacion_lente_1_' + str(i)
                            graduacionPrimera = request.POST.get(graduacionPrimera)
                            producto.append(graduacionPrimera)
                            foco = 'foco_lente' + str(i)
                            foco = request.POST.get(foco)
                            producto.append(foco)
                            if foco != 'monofocal':
                                graduacionSegunda = 'graduacion_lente_2_' + str(i)
                                graduacionSegunda = request.POST.get(graduacionSegunda)
                                producto.append(graduacionSegunda)
                            fotocromatico = 'fotocromatico_lente' + str(i)
                            if fotocromatico in request.POST:
                                producto.append(request.POST.get(fotocromatico))
                            antirreflex = 'antirreflex_lente' + str(i)
                            if antirreflex in request.POST:
                                producto.append(request.POST.get(antirreflex))
                            armazon = 'armazon_lente' + str(i)
                            if armazon in request.POST:
                                producto.append(request.POST.get(armazon))
                                
                            lista_detallada_productos.append(producto)
                            
                        elif tipo_producto == 'lentillas':
                            producto.append(tipo_producto)
                            modelo_lentilla = 'modelo_lentilla' + str(i)
                            modelo_lentilla = request.POST.get(modelo_lentilla)
                            producto.append(modelo_lentilla)
                            cantidad_lentillas = 'cantidad_lentillas' + str(i)
                            cantidad_lentillas = request.POST.get(cantidad_lentillas)
                            producto.append(cantidad_lentillas)
                        
                            lista_detallada_productos.append(producto)
                        
                        elif tipo_producto == 'marco':
                            producto.append(tipo_producto)
                            modelo_marco = 'modelo_marco' + str(i)
                            modelo_marco = request.POST.get(modelo_marco)
                            producto.append(modelo_marco)
                            cantidad_marcos = 'cantidad_marcos' + str(i)
                            cantidad_marcos = request.POST.get(cantidad_marcos)
                            producto.append(cantidad_marcos)
                            
                            lista_detallada_productos.append(producto)
                            
                        elif tipo_producto == 'limpiador':
                            producto.append(tipo_producto)
                            presentacion_limpiador = 'presentacion_limpiador' + str(i)
                            presentacion_limpiador = request.POST.get(presentacion_limpiador)
                            producto.append(presentacion_limpiador)
                            cantidad_limpiador = 'cantidad_limpiador' + str(i)
                            cantidad_limpiador = request.POST.get(cantidad_limpiador)
                            producto.append(cantidad_limpiador)
                            
                            lista_detallada_productos.append(producto)
                            
                        elif tipo_producto == 'estuche':
                            producto.append(tipo_producto)
                            modelo_estuche = 'modelo_estuche' + str(i)
                            modelo_estuche = request.POST.get(modelo_estuche)
                            producto.append(modelo_estuche)
                            cantidad_estuches = 'cantidad_estuches' + str(i)
                            cantidad_estuches = request.POST.get(cantidad_estuches)
                            producto.append(cantidad_estuches)
                            
                            lista_detallada_productos.append(producto)
                total = 0
                productos = []            
                for producto in lista_detallada_productos:
                    el_producto = []
                    if producto[0] == 'Lente':
                        precio_prod = 2500
                        descripcion_prod = f'{producto[0]} {producto[1]} {producto[2]} {producto[3]}, de graduación {producto[4]} {producto[5]}'
                        if producto[5] == 'bifocal' or producto[5] == 'progresiva':
                            precio_prod = precio_prod + 500
                            descripcion_prod = descripcion_prod + f' de {producto[6]}'
                            if len(producto) >= 8:
                                precio_prod += 200
                                descripcion_prod = descripcion_prod + f', {producto[7]}'
                                if len(producto) >= 9:
                                    precio_prod += 200
                                    descripcion_prod = descripcion_prod + f', {producto[8]}'
                                    if len(producto) >= 10:
                                        precio_prod += 200
                                        descripcion_prod = descripcion_prod + f', {producto[9]}'
                        else:
                            if len(producto) >= 7:
                                precio_prod += 200
                                descripcion_prod = descripcion_prod + f', {producto[6]}'
                                if len(producto) >= 8:
                                    precio_prod += 200
                                    descripcion_prod = descripcion_prod + f', {producto[7]}'
                                    if len(producto) >= 9:
                                        precio_prod += 200
                                        descripcion_prod = descripcion_prod + f', {producto[8]}'
                        
                        cantidad = 1
                        subtotal = precio_prod * cantidad
                        el_producto.append(descripcion_prod)
                        el_producto.append(precio_prod)
                        el_producto.append(cantidad)
                        el_producto.append(subtotal)
                        
                        total += subtotal
                    if producto[0] == 'lentillas':
                        descripcion_prod = f'Lentillas {producto[1]}'
                        precio_prod = 3000
                        cantidad = int(producto[2])
                        subtotal = precio_prod * cantidad
                        el_producto.append(descripcion_prod)
                        el_producto.append(precio_prod)
                        el_producto.append(cantidad)
                        el_producto.append(subtotal)
                        total += subtotal
                    if producto[0] == 'marco':
                        descripcion_prod = f'Marco {producto[1]}'
                        precio_prod = 3000
                        cantidad = int(producto[2])
                        subtotal = precio_prod * cantidad
                        el_producto.append(descripcion_prod)
                        el_producto.append(precio_prod)
                        el_producto.append(cantidad)
                        el_producto.append(subtotal)
                        total += subtotal
                    if producto[0] == 'limpiador':
                        descripcion_prod = f'Limpiador de {producto[1]}'
                        precio_prod = 300
                        cantidad = int(producto[2])
                        subtotal = precio_prod * cantidad
                        el_producto.append(descripcion_prod)
                        el_producto.append(precio_prod)
                        el_producto.append(cantidad)
                        el_producto.append(subtotal)
                        total += subtotal
                    if producto[0] == 'estuche':
                        descripcion_prod = f'Estuche {producto[1]}'
                        precio_prod = 400
                        cantidad = int(producto[2])
                        subtotal = precio_prod * cantidad
                        el_producto.append(descripcion_prod)
                        el_producto.append(precio_prod)
                        el_producto.append(cantidad)
                        el_producto.append(subtotal)
                        total += subtotal
                    productos.append(el_producto)
                    
                    fecha = datetime.datetime.now()
                    dni = request.POST.get('dni')
                    for producto in productos:
                        if 'Lente' in producto[0]:
                            pedido = Pedidos()
                            pedido.descProducto = producto[0]
                            pedido.cantidad = producto[2]
                            dni_fk = Pacientes.objects.get(pk = dni)
                            pedido.dni_fk = dni_fk
                            pedido.precio = producto[1]
                            pedido.estado = "Pendiente"
                            pedido.fechaSolicitud = fecha
                            pedido.operador = request.user.username
                            pedido.save()
                        #!--------------------
                            
                        else:
                            pedido = Pedidos()
                            pedido.descProducto = producto[0]
                            pedido.cantidad = producto[2]
                            dni_fk = Pacientes.objects.get(pk = dni)
                            pedido.dni_fk = dni_fk
                            pedido.precio = producto[1]
                            pedido.estado = "Pendiente"
                            pedido.fechaSolicitud = fecha
                            pedido.operador = request.user.username
                            pedido.save()
                            
                        #!--------------------
                return render(request, "gestionCOP/nuevoPedido.html", {'fechaActual':o_FechaActual, 'rol':rol, 'productos':productos, 'total': total})
            else:
                return render(request, "gestionCOP/nuevoPedido.html", {'fechaActual':o_FechaActual, 'rol':rol})
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            
    
    
def listarPedidos(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Ventas') or (rol =='Gerencia'):
            pedidos = Pedidos.objects.all().order_by('fechaSolicitud')
            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'pedidos':pedidos}
            return render(request, "gestionCOP/listarPedidos.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            



def modificarPedido(request, idPedido):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        fecha = datetime.datetime.now()
        if (rol =='Ventas') or (rol =='Gerencia') or (rol =='Taller'):
            if request.method =='POST':
                estado = request.POST.get('estado')
                pedido = Pedidos.objects.get(pk=idPedido)
                pedido.estado = estado
                pedido.fechaModificacion = fecha
                pedido.operadorMod = request.user.username
                pedido.save()
                mensajeB = 'Se ha modificado exitosamente'
                return render(request, "gestionCOP/modificarPedido.html", {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeB':mensajeB})
            else:
                pedido = Pedidos.objects.get(pk=idPedido)
                mensajeA = f'Modificando el pedido de {pedido.descProducto} del paciente {pedido.dni_fk}.'
                
                return render(request, "gestionCOP/modificarPedido.html", {'fechaActual':o_FechaActual, 'rol':rol, 'mensajeA':mensajeA})
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            


def listarPedidosTaller(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if (rol =='Taller') or (rol =='Gerencia'):
            pedidos = Pedidos.objects.all().order_by('fechaSolicitud')
            contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'pedidos':pedidos}
            return render(request, "gestionCOP/listarPedidosTaller.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            



def asistenciaDePacientes(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if rol =='Gerencia':
            if request.method == "POST":
                tipo = request.POST.get('tipo')
                if tipo == 'semana':
                    semana = request.POST.get('semana').split('W')
                    nro_semana = int(semana[1])
                    
                    WEEK  = nro_semana - 2 # as it starts with 0 and you want week to start from sunday
                    startdate = time.asctime(time.strptime('2020 %d 0' % WEEK, '%Y %W %w')) 
                    startdate = datetime.datetime.strptime(startdate, '%a %b %d %H:%M:%S %Y') 
                    dates = [startdate.strftime('%Y-%m-%d')] 
                    for i in range(1, 7): 
                        day = startdate + datetime.timedelta(days=i)
                        dates.append(day.strftime('%Y-%m-%-d')) 
                    
                    # dates es una lista con los dias de la semana elegida como elementos ['2020-11-29', '2020-11-30', '2020-12-01', '2020-12-02', '2020-12-03', '2020-12-04', '2020-12-05']
                    
                    id_turnos_de_la_semana = []
                    turnos = Turnos.objects.all().order_by('fechaTurno')
                    for turno in turnos:
                        for fecha_de_la_semana in dates:
                            fecha_del_turno = str(turno.fechaTurno.year) + '-' + str(turno.fechaTurno.month) + '-' + str(turno.fechaTurno.day)
                            if fecha_del_turno == fecha_de_la_semana:
                                if turno.medico != '':
                                    id_turnos_de_la_semana.append(turno.id)
                                    
                    pacientes = []
                    for id_turno in id_turnos_de_la_semana:
                        turno = Turnos.objects.get(id=id_turno)
                        paciente = turno.dni_fk
                        nombrePaciente = paciente.nombre + " " + paciente.apellido + " (" + str(paciente.dni) + ")"
                        pacientes.append(nombrePaciente )
                        
                    #eliminando elementos repetidos
                    
                    setPacientes = set(pacientes)
                    listaPacientes = list(setPacientes)
                    
                    mensaje = f'Listando pacientes que asistieron en los turnos del {dates[0]} al {dates[6]}'
                    
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'listaPacientes': listaPacientes}
                    
                    return render(request, "gestionCOP/asistenciaDePacientes.html", contexto)
                elif tipo == 'mes':
                    mes_buscado = request.POST.get('mes')
                    turnos = Turnos.objects.all().order_by('fechaTurno')
                    id_turnos_del_mes = []
                    for turno in turnos:
                        if turno.fechaTurno.month == int(mes_buscado):
                            if turno.medico != "":
                                id_turnos_del_mes.append(turno.id)
                    
                    pacientes = []
                    for id_turno in id_turnos_del_mes:
                        turno = Turnos.objects.get(id=id_turno)
                        paciente = turno.dni_fk
                        nombrePaciente = paciente.nombre + " " + paciente.apellido + " (" + str(paciente.dni) + ")"
                        pacientes.append(nombrePaciente )
                    
                    #eliminando elementos repetidos
                    
                    setPacientes = set(pacientes)
                    listaPacientes = list(setPacientes)
                    
                    mensaje = f'Listando pacientes que asistieron en los turnos del mes {mes_buscado}.'
                    
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'listaPacientes': listaPacientes}
                    
                    return render(request, "gestionCOP/asistenciaDePacientes.html", contexto)
            else:
                return render(request, "gestionCOP/asistenciaDePacientes.html")
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            
    
def inasistencias(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if rol =='Gerencia':
            if request.method == "POST":
                tipo = request.POST.get('tipo')
                if tipo == 'semana':
                    semana = request.POST.get('semana').split('W')
                    nro_semana = int(semana[1])
                    
                    WEEK  = nro_semana - 2 # as it starts with 0 and you want week to start from sunday
                    startdate = time.asctime(time.strptime('2020 %d 0' % WEEK, '%Y %W %w')) 
                    startdate = datetime.datetime.strptime(startdate, '%a %b %d %H:%M:%S %Y') 
                    dates = [startdate.strftime('%Y-%m-%d')] 
                    for i in range(1, 7): 
                        day = startdate + datetime.timedelta(days=i)
                        dates.append(day.strftime('%Y-%m-%-d')) 
                    
                    # dates es una lista con los dias de la semana elegida como elementos ['2020-11-29', '2020-11-30', '2020-12-01', '2020-12-02', '2020-12-03', '2020-12-04', '2020-12-05']
                    
                    id_turnos_de_la_semana = []
                    turnos = Turnos.objects.all().order_by('fechaTurno')
                    for turno in turnos:
                        for fecha_de_la_semana in dates:
                            fecha_del_turno = str(turno.fechaTurno.year) + '-' + str(turno.fechaTurno.month) + '-' + str(turno.fechaTurno.day)
                            if fecha_del_turno == fecha_de_la_semana:
                                if turno.medico == '':
                                    id_turnos_de_la_semana.append(turno.id)
                                    
                    pacientes = []
                    for id_turno in id_turnos_de_la_semana:
                        turno = Turnos.objects.get(id=id_turno)
                        paciente = turno.dni_fk
                        nombrePaciente = paciente.nombre + " " + paciente.apellido + " (" + str(paciente.dni) + ")"
                        pacientes.append(nombrePaciente )
                        
                    #eliminando elementos repetidos
                    
                    setPacientes = set(pacientes)
                    listaPacientes = list(setPacientes)
                    
                    mensaje = f'Listando pacientes que asistieron en los turnos del {dates[0]} al {dates[6]}'
                    
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'listaPacientes': listaPacientes}
                    
                    return render(request, "gestionCOP/asistenciaDePacientes.html", contexto)
                elif tipo == 'mes':
                    mes_buscado = request.POST.get('mes')
                    turnos = Turnos.objects.all().order_by('fechaTurno')
                    id_turnos_del_mes = []
                    for turno in turnos:
                        if turno.fechaTurno.month == int(mes_buscado):
                            if turno.medico == "":
                                id_turnos_del_mes.append(turno.id)
                    
                    pacientes = []
                    for id_turno in id_turnos_del_mes:
                        turno = Turnos.objects.get(id=id_turno)
                        paciente = turno.dni_fk
                        nombrePaciente = paciente.nombre + " " + paciente.apellido + " (" + str(paciente.dni) + ")"
                        pacientes.append(nombrePaciente )
                    
                    #eliminando elementos repetidos
                    
                    setPacientes = set(pacientes)
                    listaPacientes = list(setPacientes)
                    
                    mensaje = f'Listando pacientes que asistieron en los turnos del mes {mes_buscado}.'
                    
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'listaPacientes': listaPacientes}
                    
                    return render(request, "gestionCOP/asistenciaDePacientes.html", contexto)
            else:
                return render(request, "gestionCOP/inasistencias.html", {'fechaActual':o_FechaActual, 'rol':rol,})
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            
    
def pedidosDePacientes(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if rol =='Gerencia':
            if request.method == "POST":
                tipo = request.POST.get('tipo')
                if tipo == 'semana':
                    semana = request.POST.get('semana').split('W')
                    nro_semana = int(semana[1])
                    
                    WEEK  = nro_semana - 2 # as it starts with 0 and you want week to start from sunday
                    startdate = time.asctime(time.strptime('2020 %d 0' % WEEK, '%Y %W %w')) 
                    startdate = datetime.datetime.strptime(startdate, '%a %b %d %H:%M:%S %Y') 
                    dates = [startdate.strftime('%Y-%m-%d')] 
                    for i in range(1, 7): 
                        day = startdate + datetime.timedelta(days=i)
                        dates.append(day.strftime('%Y-%m-%-d')) 
                    
                    # dates es una lista con los dias de la semana elegida como elementos ['2020-11-29', '2020-11-30', '2020-12-01', '2020-12-02', '2020-12-03', '2020-12-04', '2020-12-05']

                    id_pedidos = []
                    pedidos = Pedidos.objects.all().order_by('fechaSolicitud')
                    for pedido in pedidos:
                        for fecha in dates:
                            fecha_de_pedido = str(pedido.fechaSolicitud.year) + '-' + str(pedido.fechaSolicitud.month) + '-' + str(pedido.fechaSolicitud.day)
                            if fecha_de_pedido == fecha:
                                id_pedidos.append(pedido.id)
                                
                    pacientes = []
                    for id_pedido in id_pedidos:
                        pedido = Pedidos.objects.get(id=id_pedido)
                        paciente = pedido.dni_fk
                        nombrePaciente = paciente.nombre + " " + paciente.apellido + " (" + str(paciente.dni) + ")"
                        pacientes.append(nombrePaciente )
                        
                    #eliminando elementos repetidos
                    
                    setPacientes = set(pacientes)
                    listaPacientes = list(setPacientes)
                    
                    mensaje = f'Listado de pacientes que realizaron algún pedido en la semana del {dates[0]} al {dates[6]}'
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol,  'mensaje': mensaje, 'listaPacientes': listaPacientes}
                    return render(request, "gestionCOP/pedidosDePacientes.html", contexto)
                
                if tipo == 'mes':
                    mes_buscado = request.POST.get('mes')
                    pedidos = Pedidos.objects.all().order_by('fechaSolicitud')
                    id_pedidos_del_mes = []
                    for pedido in pedidos:
                        if pedido.fechaSolicitud.month == int(mes_buscado):
                            id_pedidos_del_mes.append(pedido.id)
                    
                    pacientes = []
                    for id_pedido in id_pedidos_del_mes:
                        pedido = Pedidos.objects.get(id=id_pedido)
                        paciente = pedido.dni_fk
                        nombrePaciente = paciente.nombre + " " + paciente.apellido + " (" + str(paciente.dni) + ")"
                        pacientes.append(nombrePaciente )
                        
                    #eliminando elementos repetidos
                    
                    setPacientes = set(pacientes)
                    listaPacientes = list(setPacientes)
                    #----

                    mensaje = listaPacientes
                    contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'listaPacientes': listaPacientes}
                    return render(request, "gestionCOP/pedidosDePacientes.html", contexto)
                
            else:
                return render(request, "gestionCOP/pedidosDePacientes.html", {'fechaActual':o_FechaActual, 'rol':rol, })
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})            


def topProductosVendidos(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if rol =='Gerencia':
            if request.method =='POST':
                mes_buscado = request.POST.get('mes')
                pedidos = Pedidos.objects.all().order_by('fechaSolicitud')
                id_pedidos_del_mes = []
                for pedido in pedidos:
                    if pedido.fechaSolicitud.month == int(mes_buscado):
                        id_pedidos_del_mes.append(pedido.id)
                mensaje = id_pedidos_del_mes
                
                listado_de_productos = []
                for id_pedido in id_pedidos_del_mes:
                    producto = ''
                    pedido = Pedidos.objects.get(id=id_pedido)
                    i = 1
                    if 'Lente' in pedido.descProducto:
                        if 'armazón' in pedido.descProducto:
                            producto = 'Lente con armazón'
                            while i <= pedido.cantidad:
                                listado_de_productos.append(producto)
                                i += 1
                        else:
                            producto = 'Lente sin armazón'
                            while i <= pedido.cantidad:
                                listado_de_productos.append(producto)
                                i += 1
                    else:
                        producto = pedido.descProducto
                        while i <= pedido.cantidad:
                                listado_de_productos.append(producto)
                                i += 1
                                
                def myFunc(e):
                    return e[1]                
                                
                listado_de_productos.sort()
                
                listado_producto_una_vez = []
                
                producto_cantidad = []
                for producto in listado_de_productos:
                    if not producto in listado_producto_una_vez:
                        tipo_producto = []
                        tipo_producto.append(producto)
                        tipo_producto.append(listado_de_productos.count(producto))
                        listado_producto_una_vez.append(producto)
                        producto_cantidad.append(tipo_producto)
                
                producto_cantidad.sort(reverse=True, key=myFunc)
                
                mensaje = 'casa'
                
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': producto_cantidad, 'producto_cantidad':producto_cantidad}
                return render(request, "gestionCOP/ventasPorVendedores.html", contexto)
            else:
                return render(request, "gestionCOP/topProductosVendidos.html", {'fechaActual':o_FechaActual, 'rol':rol})
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})


def ventasPorVendedores(request):
    if not request.user.is_authenticated:
        contexto = {"mensaje":"Debe autenticarse para acceder"}
        return render(request, "gestionCOP/login.html", contexto)
    else:
        o_FechaActual = objetoFechaHoy()
        rol = defineRol(request)
        if rol =='Gerencia':
            if request.method == "POST":
                mes_buscado = request.POST.get('mes')
                pedidos = Pedidos.objects.all().order_by('fechaSolicitud')
                id_pedidos_del_mes = []
                for pedido in pedidos:
                    if pedido.fechaSolicitud.month == int(mes_buscado):
                        id_pedidos_del_mes.append(pedido.id)
                mensaje = id_pedidos_del_mes
                
                list_vendedores = []
                for id_pedido in id_pedidos_del_mes:
                    i = 1
                    pedido = Pedidos.objects.get(id=id_pedido)
                    while i <= pedido.cantidad:
                        list_vendedores.append(pedido.operador)
                        i += 1
                list_vendedores.sort()
                listado_vendedores = []
                listado_ventas_x_vend = []
                
                for vendedor in list_vendedores:
                    if not vendedor in listado_vendedores:
                        vendedor_ventas = []
                        vendedor_ventas.append(vendedor)
                        vendedor_ventas.append(list_vendedores.count(vendedor))
                        listado_vendedores.append(vendedor)
                        listado_ventas_x_vend.append(vendedor_ventas)
                
                def myFunc(e):
                    return e[1]
                
                listado_ventas_x_vend.sort(reverse=True, key=myFunc)
                
                mensaje = f'Ventas por vendedor en el mes {mes_buscado}'
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': mensaje, 'listado_ventas_x_vend':listado_ventas_x_vend}
                return render(request, "gestionCOP/topProductosVendidos.html", contexto)        
            else:
                
                idUsuario = request.user.id
                
                rol = defineRol(request)
                
                
                    
                contexto = {'fechaActual':o_FechaActual, 'rol':rol, 'mensaje': rol,'fechaActual':o_FechaActual, 'rol':rol}
                return render(request, "gestionCOP/ventasPorVendedores.html", contexto)
        else:
            mensaje = "Lo sentimos, usted no posee los permisos para acceder al anterior módulo."
            return render(request, "gestionCOP/index.html", {'mensaje': mensaje, 'fechaActual':o_FechaActual, 'rol':rol})