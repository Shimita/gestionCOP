contador  = 1;

function cancelar(elemento) {
    var divProducto = elemento.parentNode;
    divProducto.parentNode.removeChild(divProducto);

}

function nuevoProducto() {
    contador ++;

    let inputOculto = document.getElementById("oculto").setAttribute("value", contador);
    let nuevoProducto = document.getElementById("divProducto1").cloneNode(true);
    let id_div_nuevo_prod = "divProducto" + contador;
    nuevoProducto.setAttribute('id', id_div_nuevo_prod);
    document.getElementById("divProductos").appendChild(nuevoProducto);

    var select_tipo_prod = nuevoProducto.getElementsByClassName('select_tipo_prod');
    var id_select_tipo_prod = 'select_tipo_prod' + contador;
    select_tipo_prod[0].setAttribute('id', id_select_tipo_prod);

    var name_select_tipo_prod = 'select_tipo_prod' + contador;
    select_tipo_prod[0].setAttribute('name', name_select_tipo_prod);

    var div_op_lente = nuevoProducto.getElementsByClassName("div_op_lente");
    let id_div_lente = 'divLente' + contador;
    div_op_lente[0].setAttribute('id', id_div_lente);

    var select_lateralidad_lente = nuevoProducto.getElementsByClassName('select_lateralidad_lente');
    var name_select_lateralidad_lente = 'lateralidad_lente' + contador;
    select_lateralidad_lente[0].setAttribute('name', name_select_lateralidad_lente);

    var name_material_lente = 'material_lente' + contador;
    var select_material_lente = nuevoProducto.getElementsByClassName('select_material_lente');
    select_material_lente[0].setAttribute('name', name_material_lente);

    var name_convergencia_lente = 'convergencia_lente' + contador;
    var select_convergencia_lente = nuevoProducto.getElementsByClassName('select_convergencia_lente');
    select_convergencia_lente[0].setAttribute('name', select_convergencia_lente[0].getAttribute('name'));

    var name_graduacion_lente_1 = 'graduacion_lente_1_' + contador;
    var input_graduacion_lente_1 = nuevoProducto.getElementsByClassName('input_graduacion_lente_1');
    input_graduacion_lente_1[0].setAttribute('name', name_graduacion_lente_1);

    var select_foco = nuevoProducto.getElementsByClassName('select_foco');
    var id_select_foco = 'select_foco' + contador;
    select_foco[0].setAttribute('id', id_select_foco);

    var name_select_foco = 'foco_lente' + contador;
    select_foco[0].setAttribute('name', name_select_foco);

    var div_seg_grad = div_op_lente[0].getElementsByClassName("div_seg_grad")
    let id_div_seg_grad = 'segundaGraduacion' + contador;
    div_seg_grad[0].setAttribute('id', id_div_seg_grad);

    var name_input_graduacion_lente_2 = 'input_graduacion_lente_2_' + contador;
    var input_graduacion_lente_2 = nuevoProducto.getElementsByClassName('input_graduacion_lente_2');
    input_graduacion_lente_2[0].setAttribute('name', name_input_graduacion_lente_2);

    var name_input_fotocromatico_lente = 'fotocromatico_lente' + contador;
    var input_fotocromatico_lente = nuevoProducto.getElementsByClassName('input_fotocromatico_lente');
    input_fotocromatico_lente[0].setAttribute('name', name_input_fotocromatico_lente);

    var name_input_antirreflex_lente = 'antirreflex_lente' + contador;
    var input_antirreflex_lente = nuevoProducto.getElementsByClassName('input_antirreflex_lente');
    input_antirreflex_lente[0].setAttribute('name', name_input_antirreflex_lente);

    var name_input_armazon_lente = 'armazon_lente' + contador;
    var input_armazon_lente = nuevoProducto.getElementsByClassName('input_armazon_lente');
    input_armazon_lente[0].setAttribute('name', name_input_armazon_lente);

    var name_modelo_lentilla = 'modelo_lentilla' + contador;
    var select_modelo_lentilla = nuevoProducto.getElementsByClassName('select_modelo_lentilla');
    select_modelo_lentilla[0].setAttribute('name', name_modelo_lentilla);

    var name_cantidad_lentillas = 'cantidad_lentillas' + contador;
    var input_cantidad_lentilla = nuevoProducto.getElementsByClassName('input_cantidad_lentilla');
    input_cantidad_lentilla[0].setAttribute('name', name_cantidad_lentillas);

    var name_modelo_marco = 'modelo_marco' + contador;
    var select_modelo_marco = nuevoProducto.getElementsByClassName('select_modelo_marco');
    select_modelo_marco[0].setAttribute('name', name_modelo_marco);

    var name_cantidad_marcos = 'cantidad_marcos' + contador;
    var input_cantidad_marco = nuevoProducto.getElementsByClassName('input_cantidad_marco');
    input_cantidad_marco[0].setAttribute('name', name_cantidad_marcos);

    var name_presentacion_limpiador = 'presentacion_limpiador' + contador;
    var select_presentacion_limpiador = nuevoProducto.getElementsByClassName('select_presentacion_limpiador');
    select_presentacion_limpiador[0].setAttribute('name', name_presentacion_limpiador);

    var name_cantidad_limpiador = 'cantidad_limpiador' + contador;
    var input_cantidad_limpiador = nuevoProducto.getElementsByClassName('input_cantidad_limpiador');
    input_cantidad_limpiador[0].setAttribute('name', name_cantidad_limpiador);

    var name_modelo_estuche = 'modelo_estuche' + contador;
    var select_modelo_estuche = nuevoProducto.getElementsByClassName('select_modelo_estuche');
    select_modelo_estuche[0].setAttribute('name', name_modelo_estuche);

    var name_cantidad_estuches = 'cantidad_estuches' + contador;
    var input_cantidad_estuches = nuevoProducto.getElementsByClassName('input_cantidad_estuches');
    input_cantidad_estuches[0].setAttribute('name', name_cantidad_estuches);




    var boton = document.createElement('button');
    nuevoProducto.appendChild(boton);
    boton.innerHTML = "Cancelar";
    boton.setAttribute("onclick", "cancelar(this)");
    var idBoton = "cancelar" + contador;
    boton.setAttribute('id', idBoton);
    console.log(div_op_lente[0]);

}



function tipoProducto(elemento) {
    let id_select = elemento.id;
    let hermano = elemento.nextElementSibling;

    let valor = elemento.value;
    if (valor == "lentes") {
        elemento.parentNode.childNodes[5].style.display = "inline-block";
        elemento.parentNode.childNodes[7].style.display = "none";
        elemento.parentNode.childNodes[9].style.display = "none";
        elemento.parentNode.childNodes[11].style.display = "none";
        elemento.parentNode.childNodes[13].style.display = "none";
    } else if (valor == "lentillas") {
        elemento.parentNode.childNodes[7].style.display = "inline-block";
        elemento.parentNode.childNodes[5].style.display = "none";
        elemento.parentNode.childNodes[9].style.display = "none";
        elemento.parentNode.childNodes[11].style.display = "none";
        elemento.parentNode.childNodes[13].style.display = "none";
    } else if (valor == "marco") {
        elemento.parentNode.childNodes[9].style.display = "inline-block";
        elemento.parentNode.childNodes[5].style.display = "none";
        elemento.parentNode.childNodes[7].style.display = "none";
        elemento.parentNode.childNodes[11].style.display = "none";
        elemento.parentNode.childNodes[13].style.display = "none";
    } else if (valor == "limpiador") {
        elemento.parentNode.childNodes[11].style.display = "inline-block";
        elemento.parentNode.childNodes[5].style.display = "none";
        elemento.parentNode.childNodes[7].style.display = "none";
        elemento.parentNode.childNodes[9].style.display = "none";
        elemento.parentNode.childNodes[13].style.display = "none";
    } else if (valor == "estuche") {
        elemento.parentNode.childNodes[13].style.display = "inline-block";
        elemento.parentNode.childNodes[5].style.display = "none";
        elemento.parentNode.childNodes[7].style.display = "none";
        elemento.parentNode.childNodes[9].style.display = "none";
        elemento.parentNode.childNodes[11].style.display = "none";
    }

    
}

function tipoFoco(elemento) {
    let id_select = elemento.id;
    let hermano = elemento.nextElementSibling;
    console.log(hermano);
    let valor = elemento.value;
    if ((valor == "bifocal") || (valor == "progresiva")) {
        hermano.style.display = "inline-block";
    } else{
        hermano.style.display = "none";
    }
}


/* function segundaGraduacion() {
    let valor = document.getElementById("foco").value;
    if ((valor == "bifocal") || (valor == "progresiva")) {
        document.getElementById("segundaGraduacion").style.visibility = "visible";
    } else {
        document.getElementById("segundaGraduacion").style.visibility = "hidden";
    }
}*/


document.addEventListener("DOMContentLoaded", function() {
    //console.log("DOM fully loaded and parsed");
    document.getElementById('btn_nuevo_prod').onclick = nuevoProducto;
});