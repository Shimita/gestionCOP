from django.apps import AppConfig


class CatalogoyoutubeConfig(AppConfig):
    name = 'catalogoYoutube'
