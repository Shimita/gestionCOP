from django.db import models

# Create your models here.

class Pacientes(models.Model):
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    dni = models.IntegerField(primary_key=True)
    fechaNacimiento = models.DateField(null=True, blank=True)
    profesion = models.CharField(max_length=50, blank=True)
    obraSocial = models.CharField(max_length=30, blank=True)
    sexo = models.CharField(max_length=15, blank=True)
    telefono = models.CharField(max_length=20, blank=True)
    email = models.EmailField(max_length=50, blank=True)
    antecedentesPaciente = models.TextField(max_length=800, blank=True)
    antecedentesFamilia = models.TextField(max_length=800, blank=True)
    
    def __str__(self):
        return f"{self.nombre} {self.apellido}"
    
class Turnos(models.Model):
    fechasSolicitud = models.DateTimeField()
    fechaModificacion = models.DateTimeField(null=True, blank=True)
    fechaTurno = models.DateTimeField()
    cancelado = models.BooleanField()
    dni_fk = models.ForeignKey(Pacientes, on_delete=models.CASCADE, related_name="solicitoTurno")
    operador = models.CharField(max_length=50)
    operadorMod = models.CharField(max_length=50, blank=True)
    medico = models.CharField(max_length=50, blank=True)
    
class Consultas(models.Model):
    turno_fk = models.ForeignKey(Turnos, on_delete=models.CASCADE, related_name='generoCOnsulta')
    motivo = models.TextField(max_length=1000)
    diagnostico = models.TextField(max_length=3000)
    
class Pedidos(models.Model):
    descProducto = models.CharField(max_length=1000)
    cantidad = models.IntegerField()
    precio = models.IntegerField()
    dni_fk = models.ForeignKey(Pacientes, on_delete=models.CASCADE, related_name="solicitoPedido")
    estado = models.CharField(max_length=1000)
    fechaSolicitud = models.DateTimeField()
    fechaModificacion = models.DateTimeField(null=True, blank=True)
    operadorMod = models.CharField(max_length=50, blank=True)
    operador = models.CharField(max_length=50)
