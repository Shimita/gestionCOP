from django.urls import path
from django.conf.urls import url, include
from . import views
from gestionCOP.views import modificarTurnos

app_name= "gestionCOP"

urlpatterns = [
    path('', views.index, name="index"),
    path('login', views.login_view, name='login'),
    path('logout', views.logout_view, name='logout'),
    path('index/', views.index, name='index'),
    path('listarTurnos/', views.listarTurnos, name='listarTurnos'),
    path('formNuevoTurnos/', views.redirecciona, name='formNuevoTurno'),
    path('formNuevoTurnos/<horaTurno>', views.formNuevoTurno, name='formNuevoTurno'),
    path('modificarTurnos/', views.redirecciona, name='modificarTurnos'),
    path('modificarTurnos/<idTurno>', views.modificarTurnos, name='modificarTurnos'),
    path('modificarTurnos/<int:idTurno>/<int:pacienteId>/<int:year>/<int:month>/<int:day>/<hour>/', views.modificarTurnosAlDia, name='modificarTurnosAlDia'),
    path('nuevoPaciente/', views.nuevoPaciente, name='nuevoPaciente'),
    path('buscarPaciente/', views.buscarPaciente, name='buscarPaciente'),
    path('modificarPaciente/', views.redirecciona, name='modificarPaciente'),
    path('modificarPaciente/<int:dni>', views.modificarPaciente, name='modificarPaciente'),    
    path('listarPacientes/', views.listarPacientes, name='listarPacientes'),
    path('paciente-agregar/', views.pacientesAgregar, name='pacientesAgregar'),
    path('listarPacientes/', views.listarPacientes, name='listarPacientes'),
    
    path('consultasMedicas/', views.consultasMedicas, name='consultasMedicas'),
    path('consultasMedicas/<int:idTurno>', views.nuevaConsultaMedica, name='nuevaConsultaMedica'),
    path('pacienteSexoProfesion/', views.pacienteSexoProfesion, name='pacienteSexoProfesion'),
    path('pacienteSexoProfesion/<int:dni>', views.pacienteSexoProfesion, name='pacienteSexoProfesion'),
    path('listarPacientesAtendidos/', views.listarPacientesAtendidos, name='listarPacientesAtendidos'),
    path('historiaClinica/', views.historiaClinica, name='historiaClinica'),
    path('historiaClinica/<int:idTurno>', views.historiaClinica, name='historiaClinica'),
    path('nuevoPedido/', views.nuevoPedido, name='nuevoPedido'),
    path('listarPedidos/', views.listarPedidos, name='listarPedidos'),
    path('modificarPedido/', views.modificarPedido, name='modificarPedido'),
    path('modificarPedido/<int:idPedido>', views.modificarPedido, name='modificarPedido'),
    path('listarPedidosTaller/', views.listarPedidosTaller, name='listarPedidosTaller'),
    path('asistenciaDePacientes/', views.asistenciaDePacientes, name='asistenciaDePacientes'),
    path('inasistencias/', views.inasistencias, name='inasistencias'),
    path('pedidosDePacientes/', views.pedidosDePacientes, name='pedidosDePacientes'),
    path('topProductosVendidos/', views.topProductosVendidos, name='topProductosVendidos'),
    path('ventasPorVendedores/', views.ventasPorVendedores, name='ventasPorVendedores'),
]
