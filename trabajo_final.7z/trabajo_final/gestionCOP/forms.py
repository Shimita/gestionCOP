from django import forms
from gestionCOP.models import Turnos
from django.contrib.auth.models import User, Group
from gestionCOP.models import Pacientes

class SeleccionaFecha(forms.Form):
    fecha = forms.DateTimeField(label='Seleccione una fecha', widget=forms.SelectDateWidget)

class FormTurnoNuevo(forms.Form):
    dni = forms.IntegerField()
    nombre = forms.CharField(widget=forms.TextInput())
    apellido = forms.CharField()


def opcionesMedicos():
    medicos = User.objects.filter(groups=1)
    a_medicos = []
    for medico in medicos:
        c_nombreApellido = medico.first_name + " " + medico.last_name
        a_medicos.append(c_nombreApellido)
    return a_nombresDeMedicos

class FormModificarTurno(forms.ModelForm):
    medico = forms.ModelChoiceField(queryset=User.objects.filter(groups=1), initial=0)
    cancelar = forms.BooleanField(required=False)    
    class Meta:
        model = Turnos
        
        fields = [
            'medico',
            'cancelar',
        ]
        
        labels = {
            'medico':'Seleccione médico',
            'cancelar':'Cancelar Turno'
        }

class Calendario2(forms.Form):
    date = forms.DateTimeField(
        label='Cambiar fecha asignada:',
        required=False, 
        input_formats=['%d/%m/%Y'],
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control datetimepicker-input',
            'data-target': '#datetimepicker1'
            })
        )

        

    
class Calendario(forms.Form):
    date = forms.DateTimeField(
        input_formats=['%d/%m/%Y'],
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control datetimepicker-input',
            'data-target': '#datetimepicker1'
            })
        )

class NuevoPaciente(forms.Form):
    nombre = forms.CharField(max_length=50)
    apellido = forms.CharField(max_length=50)
    dni = forms.IntegerField()
    obraSocial = forms.CharField(required=False)
    telefono = forms.CharField(required=False)
    email = forms.EmailField(required=False)


class FechaNacimiento(forms.Form):
    date = forms.DateTimeField(
        label='Cambiar fecha asignada:',
        required=False, 
        input_formats=['%d/%m/%Y'],
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control datetimepicker-input',
            'data-target': '#datetimepicker1'
            })
        )
    
class BuscarPorDNI(forms.Form):
    dni = forms.IntegerField(label = "")

class BuscarPorNombre(forms.Form):
    nombre = forms.CharField(label = "")
    
    
class NuevaConsulta(forms.Form):
    motivo = forms.CharField(label = "Motivo", widget=forms.Textarea)
    diagnostico = forms.CharField(label = "Diagnóstico", widget=forms.Textarea)
    
class PacienteSexoProfesion(forms.Form):
    sexo = forms.CharField(label = "Sexo:")
    profesion = forms.CharField(label = "Profesión:")
    app = forms.CharField(label = "A.P.P.:", widget=forms.Textarea)
    apf = forms.CharField(label = "A.P.F.:", widget=forms.Textarea)
    

OPCIONES = [
    ('Dia', 'Dia'),
    ('Mes', 'Mes'),
    ('Año', 'Año'),
]
class PacientesPorFecha(forms.Form):
    tipo = forms.CharField(label = "Lista por:", widget=forms.RadioSelect(choices=OPCIONES))
    valor = forms.DateTimeField(label='Seleccione una fecha', widget=forms.SelectDateWidget) 