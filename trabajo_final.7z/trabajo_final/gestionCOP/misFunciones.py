import datetime
from django.contrib.auth.models import User, Group
from django.shortcuts import render

# OBTENER FECHA DE HOY en una cadena para la cabecera de la pagina

def objetoFechaHoy():
    fechaActual = datetime.datetime.now()
    fechaActual = fechaActual.date()
    return fechaActual

def defineRol(request):
    usuario = request.user
    users_in_group = Group.objects.get(name="Médico").user_set.all()
    if usuario in users_in_group:
        rol = "Médico"
    users_in_group = Group.objects.get(name="Secretaría").user_set.all()
    if usuario in users_in_group:
        rol = "Secretaría"
    users_in_group = Group.objects.get(name="Taller").user_set.all()
    if usuario in users_in_group:
        rol = "Taller"
    users_in_group = Group.objects.get(name="Ventas").user_set.all()
    if usuario in users_in_group:
        rol = "Ventas"    
    users_in_group = Group.objects.get(name="Gerencia").user_set.all()
    if usuario in users_in_group:
        rol = "Gerencia"
    return rol


def fechaBuscada(request):
    dia = request['fecha_day']
    mes = request['fecha_month']
    anno = request['fecha_year']

    dia = int(dia)
    mes = int(mes)
    anno = int(anno)
    fecha = datetime.date(anno, mes, dia)
    return fecha


def fechaACadena(horaTurno):
    horaMinuto = horaTurno[-5:]
    hora = horaMinuto[0:2]
    hora = int(hora)
    minutos = horaMinuto[-2:]
    minutos = int(minutos)
    fecha = horaTurno.replace(horaMinuto, '')
    anno = fecha[-4:]
    anno = int(anno)
    mes = mesEnNumero(horaTurno)
    mes = int(mes)
    dia = diaEnNumero(horaTurno)
    dia= int(dia)
    o_fechaDelTurno = datetime.datetime(anno, mes, dia, hour=hora, minute=minutos)
    return o_fechaDelTurno
    



# TRANSFORMA LOS OBJETOS TURNO EN ARREGLO conjDeTurnos[turno[id, fechaTurno, etc], turno2[]]
def turnosOcupadosAArreglo(o_todosLosTurnosOcupados):
    a_todosLosTurnosOcupados = []
    for turnoOcupado in o_todosLosTurnosOcupados:
        a_turnoOcupado = []
        a_turnoOcupado.append(turnoOcupado.id)
        a_turnoOcupado.append(turnoOcupado.fechaTurno)
        a_turnoOcupado.append(turnoOcupado.fechasSolicitud)
        a_turnoOcupado.append(turnoOcupado.dni_fk)
        a_turnoOcupado.append(turnoOcupado.medico)
        
        a_todosLosTurnosOcupados.append(a_turnoOcupado)
    return a_todosLosTurnosOcupados


#Devuelve un array de cadenas con los posibles turnos de un dia ['8:00', '8:30', '9:00']
def turnosDelDia():
    turnos = []
    for hora in range(8, 18):
        horaEnPunto = datetime.time(hora, 00, 00)
        horaEnPunto = horaEnPunto.strftime('%H:%M')
        turnos.append(horaEnPunto)
        horaYMedia = datetime.time(hora, 30, 00)
        horaYMedia = horaYMedia.strftime('%H:%M')
        turnos.append(horaYMedia)
    return turnos


def planillaDeTurnos(turnosOcupados, fechaActual):
    turnos = []
    for hora in range(8, 18):
        horaEnPunto = datetime.time(hora, 00, 00)
        horaEnPunto = horaEnPunto.strftime('%H:%M')
        turnos.append(horaEnPunto)
        horaYMedia = datetime.time(hora, 30, 00)
        horaYMedia = horaYMedia.strftime('%H:%M')
        turnos.append(horaYMedia)
    posiblesTurnos = turnos

    todosLosTurnosDelDia = []
    if turnosOcupados:
        for turno in posiblesTurnos:
            turnoEvaluado= []
            estaOcupado = False
            for turnoOcupado in turnosOcupados:
                horaDelTurnoOcupado = turnoOcupado[1]
                horaDelTurnoOcupado = horaDelTurnoOcupado.strftime('%H:%M')
                
                if horaDelTurnoOcupado == turno:
                    estaOcupado = True
                    id_turno = turnoOcupado[0]
                    nombre = turnoOcupado[3]
                    fechaDelTurno = turnoOcupado[4]
            if estaOcupado == True:
                turnoEvaluado.append(id_turno)
                turnoEvaluado.append(turno)
                turnoEvaluado.append(turnoOcupado[2])
                turnoEvaluado.append(nombre)
                turnoEvaluado.append(fechaDelTurno)
                todosLosTurnosDelDia.append(turnoEvaluado)                               
            else:
                turnoEvaluado.append('')
                turnoEvaluado.append(turno)
                turnoEvaluado.append('No solicitado')
                turnoEvaluado.append('  --')
                turnoEvaluado.append('  --') 
                todosLosTurnosDelDia.append(turnoEvaluado)               
    else:
        for turno in posiblesTurnos:
            turnoEvaluado = []
            turnoEvaluado.append('')
            turnoEvaluado.append(turno)
            turnoEvaluado.append('No solicitado')
            turnoEvaluado.append('   --')
            turnoEvaluado.append('   --')
            todosLosTurnosDelDia.append(turnoEvaluado)
    return todosLosTurnosDelDia




def procesaDatosNuevoTurno(datosFormulario):
    dni = datosFormulario['dni']
    nombre = datosFormulario['nombre']
    apellido = datosFormulario['apellido']
    datos = nombre + apellido
    return datos




def mesEnNumero(cadena):
    numeroDelMes = ""
    if "Enero" in cadena:
        numeroDelMes = 1
    elif "Febrero" in cadena:
        numeroDelMes = 2
    elif "Marzo" in cadena:
        numeroDelMes = 3
    elif "Abril" in cadena:
        numeroDelMes = 4
    elif "Mayo" in cadena:
        numeroDelMes = 5
    elif "Junio" in cadena:
        numeroDelMes = 6
    elif "Julio" in cadena:
        numeroDelMes = 7
    elif "Agosto" in cadena:
        numeroDelMes = 8
    elif "Septiembre" in cadena:
        numeroDelMes = 9
    elif "Ocutubre" in cadena:
        numeroDelMes = 10
    elif "Noviembre" in cadena:
        numeroDelMes = 11
    elif "Diciembre" in cadena:
        numeroDelMes = 12
    return numeroDelMes
    

def diaEnNumero(cadena):
    dia = cadena[0:2]
    dia = dia.strip()
    return dia
    



def recuperarMedicos():
    medicos = User.objects.filter(groups=1)
    return medicos

    
# Convertimos el objeto datetime a string con formato dd/mm/aaaa
'''def planillaDeTurnos(turnosOcupados):
    hola = []
    for turnoOcupado in turnosOcupados:
        objetoFecha = turnoOcupado.fechaTurno
        #cadenaFecha = objetoFecha.strftime('%d/%m/%Y') 
        cadenaFecha = objetoFecha.strftime('%H:%M')
        hola.append(cadenaFecha)
    #hoy = datetime.datetime.today()
    #cadenaFecha = hoy.strftime('%H:%M')
    #hola += cadenaFecha
    
    turnos = []
    for hora in range(8, 18):
        horaEnPunto = datetime.time(hora, 00, 00)
        horaEnPunto = horaEnPunto.strftime('%H:%M')
        turnos.append(horaEnPunto)
        horaYMedia = datetime.time(hora, 30, 00)
        horaYMedia = horaYMedia.strftime('%H:%M')
        turnos.append(horaYMedia)
    
    
    
    
    todosLosTurnosDelDia = turnos
    
    
    
    
    
    for turno in todosLosTurnosDelDia:
        datosDeUnTurno = []
        for turnoPedido in hola:
            if turno == turnoPedido:
                datosDeUnTurno.append(turno)
                datosDeUnTurno.append(turnoOcupado.fechasSolicitud)
                datosDeUnTurno.append(turnoOcupado.dni_fk)
                datosDeUnTurno.append(turnoOcupado.medico)
            else:
                datosDeUnTurno.append(turno)
                datosDeUnTurno.append('No solicitado')
                datosDeUnTurno.append('')
                datosDeUnTurno.append('')
            todosLosTurnosDelDia.append(datosDeUnTurno)
    return todosLosTurnosDelDia
    


    return hola'''

'''def planillaDeTurnos(turnos, ):
    hoy = datetime.date.today()
    TurnosOcupadoHoy = ""
    for turno in turnos:
        '''
    

